import numpy as np
import math

class lda(object):

    def __init__(self, Py0 = 0, Py1 = 0, mean0 = np.zeros(m), mean1 = np.zeros(m), sigma = np.zeros((m,m))):
        self.Py0 = Py0
        self.Py1 = Py1
        self.mean0 = mean0
        self.mean1 = mean1
        self.sigma = sigma

    def fit(self, Py0, Py1, mean0, mean1, sigma):
        self.Py0 = Py0
        self.Py1 = Py1
        self.mean0 = mean0
        self.mean1 = mean1
        self.sigma = sigma     

    def predict(self, X):
        term1 = math.log(self.Py1 / self.Py0)
        term2 = 1/2 * np.transpose(self.mean1) @ np.linalg.inv(self.sigma) @ self.mean1
        term3 = 1/2 * np.transpose(self.mean0) @ np.linalg.inv(self.sigma) @ self.mean0
        term4 = np.transpose(self.X) @ np.linalg.inv(self.sigma) @ np.subtract(mean1, mean0)
        return term1 - term2 + term3 + term4  