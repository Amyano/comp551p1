import numpy as np

from src.activation import sigmoid

class logreg(object):

    def __init__(self, shape, alpha = 1):
        shape[0] += 1
        self.W = np.zeros(shape, dtype=float)
        self.alpha

    def fit(self, X, Y, n, alpha = None):
        X = np.hstack((np.ones((X.shape[0], 1)), X))
        a = alpha or self.alpha
        costs = np.zeros(n)
        for i in range(n):
            # compute the hypothesis
            H = sigmoid(X @ self.W)
            # compute the cross-entropy loss as a stat
            costs[i] = - Y @ np.log(H) - (1 - Y) @ (np.log(1 - H))
            # gradient descent step
            self.W += a * X.T @ (Y - H)
        return costs

    def predict(self, x):
        return sigmoid(self.W @ x)
