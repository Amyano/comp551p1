# comp350p1

## Requirements

* Python 3.7

## Getting started

```sh
pip install poetry --user
poetry install
```

## Tasks

data is loaded into matrices, e.g. represented as numpy arrays
and panda DataFrames to fold the data.

(should we include bias in the data matrix?)

1.  [red wine quality][wine quality]

    There are 11 features, plus a quality ranging from 0 to 10.

    The quality is our taget, thus it should be converted to a binary classifier,
    where a quality of 0 to 5 is bad, and a quality of 6 to 10 is good.
    - [ ] convert quality to a binary classifier

    - [ ] The statistics we could extract from the set:
      - [ ] ratio of good and bad quality wine
      - [ ] ...

    - [ ] the data should be loaded in a 12 by _n_ numpy array.

2.  [breast cancer][breast cancer diagnosis]

    There are 10 features, plus a diagnosis classifier (M = malignant, B = benign)

    X1,X2,Y1,Y2 matrix.

    for Y1: 1 is good quality, 0 is bad.    Y2: 1 is benign   2 is malignant

    Py1P= p(y1)=1(positive) Py1N
    Py2N= p(y2)=0(Negative) Py2N

    | #  |  Attribute                   | Domain                          |
    | -- | ---------------------------- | ------                          |
    | 1  | Sample code number           | id                              |
    | 2  | Clump Thickness              | 1 - 10                          |
    | 3  | Uniformity of Cell Size      | 1 - 10                          |
    | 4  | Uniformity of Cell Shape     | 1 - 10                          |
    | 5  | Marginal Adhesion            | 1 - 10                          |
    | 6  | Single Epithelial Cell Size  | 1 - 10                          |
    | 7  | Bare Nuclei                  | 1 - 10                          |
    | 8  | Bland Chromatin              | 1 - 10                          |
    | 9  | Normal Nucleoli              | 1 - 10                          |
    | 10 | Mitoses                      | 1 - 10                          |
    | 11 | Class:                       | (2 for benign, 4 for malignant) |

    Four vectors= M11= \[μ11;μ21......μ111\] (11*1 size vector)  which means that average of features for the red wine set when it is good quality.
            M10 =......... bad quality
            M21 M20 Similarly.

    Sigma matrix= sigma1=  (11*11)
            sigma2=  (9*9)

 Task 2: Implement the Models

//very rough implementation design

 Class LogisticFunction:

	def __init__(self, alpha):
		//alpha is learning rate
		self.alpha = alpha

	def fit(alpha, numOfIterations, x, y_actual):
		//all weights are 1 to start?
		//what should be the stop/converge condition?
		//while loop using update_rule(), stop_condition()

	def update_rule(alpha, x, w):
		//use function in lecture notes
		
	def stop_condition():
		//can test different stopping conditions

	def logistic_func(w, x):
		return 1 / (1 + e^(-log_odds()))
		
	def log_odds(w, x):

	def predict(x, w):
		return logistic_func(log_odds(x, w))
		
	def evaluate_acc(validation_input):

Class LDA:

	def __init__(self):
		
	def fit(training_data):
		//to compute P(y), mean and sigma 

		def compute_P():

		def compute_mean():
		
		def compute_sigma():
		
	def log_odds(Py, mean, sigma, x):
		//use function in lecture notes

	def predict(x, w):
		return log_odds(x, w)) > 0.5
		
	def evaluate_acc(validation_input):

K-fold_validation:
		
	def data_partition():
	
	for loop
	
	return average error

[wine quality]: https://archive.ics.uci.edu/ml/datasets/Wine+Quality
[breast cancer diagnosis]: https://archive.ics.uci.edu/ml/datasets/Breast+Cancer+Wisconsin+(Diagnostic)
